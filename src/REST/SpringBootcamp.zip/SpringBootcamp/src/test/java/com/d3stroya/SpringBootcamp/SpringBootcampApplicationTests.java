package com.d3stroya.SpringBootcamp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootcampApplicationTests {

	@Test
	void contextLoads() {
	}

}
